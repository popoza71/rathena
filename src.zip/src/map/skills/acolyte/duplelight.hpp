// Copyright (c) rAthena Dev Teams - Licensed under GNU GPL
// For more information, see LICENCE in the main folder

#pragma once

#include "../skill_impl.hpp"

// AB_DUPLELIGHT_MAGIC
class SkillDupleLightMagic : public SkillImpl {
public:
	SkillDupleLightMagic();

	void calculateSkillRatio(const Damage *wd, const block_list *src, const block_list *target, uint16 skill_lv, int32 &base_skillratio, int32 mflag) const override;
	void castendDamageId(block_list *src, block_list *target, uint16 skill_lv, t_tick tick, int32& flag) const override;
};


// AB_DUPLELIGHT_MELEE
class SkillDupleLightMelee : public WeaponSkillImpl {
public:
	SkillDupleLightMelee();

	void calculateSkillRatio(const Damage *wd, const block_list *src, const block_list *target, uint16 skill_lv, int32 &base_skillratio, int32 mflag) const override;
};
